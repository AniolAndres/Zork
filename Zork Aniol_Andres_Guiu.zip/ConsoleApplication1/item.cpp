#include "stdafx.h"
#include "item.h"
#include "constants.h"

using namespace Zerk;

item::item()
{
}


item::~item()
{
}


void item::setItem(int id, int itemType)
{
	this->id = id;
	this->itemType = itemType;
	switch (itemType)
	{
	case WEAPON:
		name = constants::WEAPONS_NAME[id];
		attack = constants::WEAPONS_DMG[id];
		defense = 0;
		effect = 0;
		weight = 1;
		break;
	case ARMOR:
		name = constants::ARMORS_NAME[id];
		attack = 0;
		defense = constants::ARMORS_DEF[id];
		effect = 0;
		weight = 1;
		break;
	case CONSUM:
		name = constants::CONSUMS_NAME[id];
		attack = 0;
		defense = 0;
		effect = constants::CONSUMS_HEALING_VALUE[id];
		weight = 1;
		break;
	case KEY_ITEM:
		name = constants::KEY_ITEMS_NAME[id];
		attack = 0;
		defense = 0;
		effect = 0;
		weight = 1;
		break;
	case GEM:	
		name = constants::GEMS_NAME[id];
		attack = 0;
		defense = 0;
		effect = constants::GEM_POWER[id];
		weight = 1;
		break;
	}
}
