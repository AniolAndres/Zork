#pragma once
#include<string>

using namespace std;


namespace Zerk
{

	class item
	{
	private:
		string name;

		int id;

		int itemType;

		int attack;

		int defense;

		int effect;

		int weight;


	public:

		item();
		~item();
		/**
		* sets item instance according to id and type given
		*/
		void setItem(int id, int idType);

		/**
		* sets item id instance according to id given
		*/
		void setId(int id) { this->id = id; };

		/**
		* sets item type instance according to id given
		*/
		int getItemType() { return itemType; };

		/**
		* return item Id
		*/
		int getId() { return id; };

		/**
		* returns item attack value
		*/
		int getAttack() { return attack; };

		/**
		* returns item defense value
		*/
		int getDefense() { return defense; };

		/**
		* returns item effect value
		*/
		int getEffect() { return effect; };

		/**
		* returns item weight value
		*/
		int getWeight() { return weight; };
	};

}