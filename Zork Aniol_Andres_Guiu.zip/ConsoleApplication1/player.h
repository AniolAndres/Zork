#pragma once
#include<iostream>
#include<string>
#include "item.h"
#include "room.h"
#include "zone.h"
#include "enemy.h"

namespace Zerk
{


	class player
	{
	private:
		room* roomPlayer;

		zone* zonePlayer;

		mapProgress* progressPlayer;

		item* itemPlayer;

		enemy* enemyPlayer;



		//Player position
		bool position[2][constants::ROOMS_TOTAL_NUMBER];

		//Direction the player is moving in
		int direction;

		//Current HP value
		int currentHp;

		//Max Hp value
		int maxHp;

		//current attack value
		int attack;

		//bonus attack due to gems
		int bonusAttack[2] = { constants::NOITEM,constants::NOITEM };
		
		//current defense
		int defense;

		//Amount of items the player is carrying
		int weight;

		//Inventory of the player TYPE,ID
		int inventory[constants::MAX_WEIGHT][2] =
		{
			{ constants::NOITEM,constants::NOITEM },
			{ constants::NOITEM,constants::NOITEM },
			{ constants::NOITEM,constants::NOITEM },
			{ constants::NOITEM,constants::NOITEM },
			{ constants::NOITEM,constants::NOITEM },
			{ constants::NOITEM,constants::NOITEM },
			{ constants::NOITEM,constants::NOITEM },
			{ constants::NOITEM,constants::NOITEM },
			{ constants::NOITEM,constants::NOITEM },
			{ constants::NOITEM,constants::NOITEM },
			{ constants::NOITEM,constants::NOITEM },
			{ constants::NOITEM,constants::NOITEM },
			{ constants::NOITEM,constants::NOITEM },
			{ constants::NOITEM,constants::NOITEM },
			{ constants::NOITEM,constants::NOITEM },
			{ constants::NOITEM,constants::NOITEM },
			{ constants::NOITEM,constants::NOITEM },
			{ constants::NOITEM,constants::NOITEM },
			{ constants::NOITEM,constants::NOITEM },
			{ constants::NOITEM,constants::NOITEM }
		};
		 //Equipped items ID,TYPE
		int itemEquiped[3][2] = 
		{
			{ constants::NOITEM,constants::NOITEM },
			{ constants::NOITEM,constants::NOITEM },
			{ constants::NOITEM,constants::NOITEM }
		};

	public:
		/**
		* Equips the item acording to id and type given
		*/
		void equip(int id, int type);

		/**
		* Unquips the item acording to id and type given
		*/
		void unequip(int type);

		/**
		* Provides description of the items Equiped
		*/
		void getEquipDescription();
		
		/**
		* returns the description of the room the player is in
		*/
		string getRoomDescription(int id) { return constants::ROOM_DESCRIPTION[id][1]; };

		/**
		* Enhances the weapon with the gem
		*/
		void enhance();

		/**
		* Sets initial position to the cell
		*/
		void setInitialPosition();

		/**
		* Returns the Room type the player is in 0=ZONES 1 =ROOMS
		*/
		int getPositionType();

		/**
		* Return the Room/Zone id the player is in
		*/
		int getPositionId();

		/**
		* sets new player position given id and type of the new ROOM/ZONE
		*/
		void setNewPosition(int a, int b);

		/**
		* Moves the player
		*/
		void movePlayer();

		/**
		* Returns if theres an enemy in the room given Room id
		*/
		bool checkEnemy(int id);

		/**
		* Writes the introduction to the room/zone the player is moving to
		*/
		void getIntro(int id, int type);

		/**
		* Writes the description of the room/zone player is moving to 
		*/
		void getDescription(int id, int type);

		/**
		* Returns description if there's any item on the room/zone
		*/
		void itemFloor();

		/**
		* sets the direction the player is moving in
		*/
		void setDirection(int a) { direction = a; };

		/**
		* returns the direction the player is moving in
		*/
		int getDirection() { return direction; };

		/**
		* Returns attack value of the player
		*/
		int getAttack() { return attack; };

		/**
		* Returns defense value of the player
		*/
		int getDefense() { return defense; };

		/**
		* Returns current HP value of the player
		*/
		int getCurrentHp() { return currentHp; };

		/**
		* Returns Max value of the player
		*/
		int getMaxHp() { return maxHp; };

		/**
		* Set bonus attack value to id given
		*/
		void setBonusAttack(int a, int b) { this->bonusAttack[a]=b; };

		/**
		* returns the Bonusattack value
		*/
		int getBonusAttack(int a) { return bonusAttack[a]; };

		/**
		* Uses an item according to string given
		*/
		void useItem(string str);

		/**
		* Picks up item from the floor to string given
		*/
		void takeItem(string str);

		/**
		* Stores item in the inventory to item type and id given
		*/
		void saveItem(int type, int id);

		/**
		* Drops item from inventory without using it to string given
		*/
		void dropItem(string str);

		/**
		* Erase consumible once used to string given
		*/
		void eraseItem(string str);

		/**
		* Returns description of the items in the inventory
		*/
		void getInventoryDescription();

		/**
		* Fights enemy according to the enemy Id given
		*/
		void fight(int id);

		/**
		* PowerUP for tests purposes
		*/
		void god() { this->attack = 30; this->defense = 20; };


		player(room* room, zone* zone, mapProgress* progress, item* item, enemy* enemy);

		~player();
	};



}