#include "stdafx.h"
#include "mapProgress.h"

using namespace Zerk;




mapProgress::mapProgress()
{
}


mapProgress::~mapProgress()
{
}
