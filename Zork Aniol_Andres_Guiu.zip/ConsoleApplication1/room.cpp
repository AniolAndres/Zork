#include "stdafx.h"
#include "room.h"
#include "constants.h"
#include<iostream>
#include<string>

using namespace Zerk;

using namespace std;


room::room()
{
}


room::~room()
{
}

/**
* modifies room instance according to id given
*/
void room::setRoom(int id, mapProgress* progress)
{
	this->id = id;
	this->name = constants::ROOMS_NAME[id];
	this->enemy = progress->getRoomStatus(id, ENEMY);
	this->item1 = progress->getRoomStatus(id, ITEM1);
	this->item2 = progress->getRoomStatus(id, ITEM2);
	this->openedDoor = progress->getRoomStatus(id, DOOR);
	this->npc = progress->getRoomStatus(id, NPC);
}

/**
* Saves room instance
*/
void room::saveRoom(mapProgress* progress)
{
	progress->setRoomStatus(id, ENEMY, enemy);
	progress->setRoomStatus(id, ITEM1, item1);
	progress->setRoomStatus(id, ITEM2, item2);
	progress->setRoomStatus(id, DOOR, door);
	progress->setRoomStatus(id, NPC, npc);
}