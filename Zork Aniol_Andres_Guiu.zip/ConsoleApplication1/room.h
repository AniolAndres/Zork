#pragma once
#include <string>
#include<iostream>
#include "mapProgress.h"

using namespace std;

namespace Zerk
{

	class room
	{
	private:
		int id;

		string name;

		bool enemy;

		int idEnemy;

		bool door;

		bool openedDoor;

		bool item1;

		bool item2;

		int itemType1;

		int itemType2;

		int idItem1;

		int idItem2;

		bool npc;

		int idNpc;

	public:

		room();
		~room();

		void setRoom(int id, mapProgress* progress);

		void saveRoom(mapProgress* progress);

		int getId() { return id; };

		void setEnemy(bool a) { this->enemy = a; };

		void setItem1(bool a) { this->item1 = a; };

		void setItem2(bool a) { this->item2 = a; };

		void setOpenedDoor(bool a) { this->openedDoor = a; };

		bool getEnemy() {return enemy;};

		bool getItem1() { return item1; };

		bool getItem2() { return item2; };

		bool getOpenedDoor() { return openedDoor; };

		bool getNpc() { return npc; };
		
	};

}