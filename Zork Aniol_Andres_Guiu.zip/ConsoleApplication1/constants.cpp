#include "stdafx.h"
#include "constants.h"
#include<iostream>
#include<cstring>

using namespace Zerk;

using namespace std;

//***********WEAPONS**********************

int constants::WEAPONS_DMG[WEAPONS_TOTAL_NUMBER] = {1,3,5};

string constants::WEAPONS_NAME[WEAPONS_TOTAL_NUMBER] = { "Knife", "Axe", "Claymore" };

//***********ARMORS**********************

int constants::ARMORS_DEF[ARMORS_TOTAL_NUMBER] = { 1,2 };

string constants::ARMORS_NAME[ARMORS_TOTAL_NUMBER] = { "Buckler", "Chainmail" };

//***********CONSUMS**********************

string constants::CONSUMS_NAME[CONSUMS_TOTAL_NUMBER] = { "Cheese" , "Potion" , "Apple" };

int constants::CONSUMS_HEALING_VALUE[CONSUMS_TOTAL_NUMBER] = { 10 , 15 , 10 };

//***********KEY ITEMS**********************

string constants::KEY_ITEMS_NAME[KEY_ITEMS_TOTAL_NUMBER] = { "Note" , "Key" };

string constants::KEY_ITEMS_USE[KEY_ITEMS_TOTAL_NUMBER] =
{
	{ "Welcome adventurer!, you may call me for now, Game Master. I'm sure you have a lot of questions regarding your current situation. \nFear not, for there is always a ray of hope, that is of course if you have the will and the guts to undergo the little games I have set out for you! \nIf you have a problem feel free to call for Help or cry, it's up to you. \nI wish you best of lucks and perhaps we will meet shortly." },
	{ "It looks like an old key, better to keep it for now." }
};

//***********GEMS**********************

string constants::GEMS_NAME[GEMS_TOTAL_NUMBER] = { "Ruby" };

int constants::GEM_POWER[GEMS_TOTAL_NUMBER] = { 5 };

//***********ROOMS**********************

string constants::ROOMS_NAME[ROOMS_TOTAL_NUMBER] = { "Cell" , "Torture chamber" , "Guards room" , "Barracks" , "Kitchen" , "Servants room" , "Treasure room" , "Throne room" , "Courtyard" };

string constants::ROOM_VARIABLES_NAME[ROOM_VARIABLES_TOTAL_NUMBER] = { "Enemy" , "Item" , "Door" };

int constants::ITEMS_ROOM[ROOMS_TOTAL_NUMBER][ITEM_TYPES_NUMBER][2] =

{
	{ { KNIFE, NOITEM },{ NOITEM, NOITEM },{ NOITEM, NOITEM },{ NOITEM, NOTE },{ NOITEM, NOITEM } },
	{ { NOITEM, NOITEM },{ BUCKLER, NOITEM },{ NOITEM, NOITEM },{ NOITEM, NOITEM },{ NOITEM, NOITEM } },
	{ { NOITEM, NOITEM },{ NOITEM, NOITEM },{ NOITEM, NOITEM },{ NOITEM, NOITEM },{ NOITEM, NOITEM } },
	{ { NOITEM, NOITEM },{ CHAINMAIL, NOITEM },{ NOITEM, NOITEM },{ NOITEM, NOITEM },{ NOITEM, NOITEM } },
	{ { NOITEM, NOITEM },{ NOITEM, NOITEM },{ CHEESE, NOITEM },{ NOITEM, NOITEM },{ NOITEM, NOITEM } },
	{ { NOITEM, NOITEM },{ NOITEM, NOITEM },{ HEALTH_POTION, NOITEM },{ NOITEM, NOITEM },{ NOITEM, NOITEM } },
	{ { NOITEM, NOITEM },{ NOITEM, NOITEM },{ NOITEM, NOITEM },{ NOITEM, NOITEM },{ REDGEM, NOITEM } },
	{ { SWORD, NOITEM },{ NOITEM, NOITEM },{ NOITEM, NOITEM },{ NOITEM, NOITEM },{ NOITEM, NOITEM } },
	{ { NOITEM, NOITEM },{ NOITEM, NOITEM },{ NOITEM, NOITEM },{ NOITEM, NOITEM },{ NOITEM, NOITEM } }
};

int constants::ENEMIES_ROOM[constants::ROOMS_TOTAL_NUMBER] =
{
	{ NOFOE },
	{ NOFOE },
	{ GOBLIN },
	{ NOFOE },
	{ NOFOE },
	{ ORC },
	{ NOFOE },
	{ TROLL },
	{ DRAGON }
};

#define WALL 90

int constants::ROOM_EXITS[constants::ROOMS_TOTAL_NUMBER][constants::EXITS][2] =
{
	{ { 2,WALL },{ 2,WALL },{ 0,0 },{ 2,WALL } },
	{ { 0,2 },{ 2,WALL },{ 2,WALL },{ 2,WALL } },
	{ { 0,0 },{ 2,WALL },{ 0,3 },{ 2,WALL } },
	{ { 2,WALL },{ 2,WALL },{ 2,WALL },{ 0,3 } },
	{ { 2,WALL },{ 2,WALL },{ 0,5 },{ 2,WALL } },
	{ { 0,4 },{ 2,WALL },{ 2,WALL },{ 2,WALL } },
	{ { 0,6 },{ 2,WALL },{ 2,WALL },{ 2,WALL } },
	{ { 2,WALL },{ 2,WALL },{ 2,WALL },{ 0,7 } },
	{ { 2,WALL },{ 0,4 },{ 2,WALL },{ 2,WALL } }
};

string constants::ROOM_DESCRIPTION[ROOMS_TOTAL_NUMBER][2] =
{
	//******ROOM1 CELL*********
	{ "You are in a Cell, it looks like no one has been here in a hundred years."   ,
	"The room around you is dark and humid and smells horribly, \nyou can barely see anything with the pale light coming from outside." },
	//******ROOM2 TORTURE CHAMBER*********
	{ "This is a torture chamber, there are bloodstains everywhere." ,
	"There are rusty torture items and devices scattered around, there are some you've never seen and can only wonder what use do they serve." },
	//******ROOM3 GUARDS ROOM*********
	{ "It's a Guard Room, in another time here was where the guards would sit and sleep till their guard was over." ,
	"The room is not in the same bad state the Cell was in but you can still notice the horrid smell. \nThere's a table and a chair in the middle, both broken." },
	//******ROOM4 BARRACKS*********
	{ "These are the barracks. Once soldiers would sleep here to rest between watches." ,
	"There's not any single bed you could use, there are no signs of being cleaned in the last years." },
	//******ROOM 5 KITCHEN*********
	{ "You are in a Kitchen or at least it looks like it was once one." ,
	"The horrid smell you faintly noticed came from this room, the walls are covered in a yellow slimy \nsubstance and you can only wonder where it comes from." },
	//******ROOM 6 SERVANTS ROOM*********
	{ "The servants room, here the servants could rest from their egotistical and narcissistic lords" ,
	"The room is in an acceptable state, as it someone had been living here recently, \na couple cloths hanging on the wall make, what you think is, a hamoc." },
	//******ROOM 7 TREASURE ROOM*********
	{ "The treasure room! this room once contained unimaginable goods and riches, nowadays is almost everything gone." ,
	"You are excited to come across this hidden room, maybe your luck is beggining to change. \nThe room is almost empty but maybe you'll be able to find something still usable. " },
	//******ROOM8 THRONE ROOM*********
	{ "A throne in the middle of this huge room can only mean one thing, the Throne room!" ,
	"Once kings and lords would have ruled from this throne, the throne still looks usable but the years have given it a shady and scary aspect." },
	//******ROOM9 COURTYARD*********
	{ "The courtyard, you can finally see the sky directly, the sun is beginning to rise as do your hopes." ,
	"The plants and flowers are clearly overgrown being unattended for so long, it's cloudy so you can't see the sun but is still an overall improvement to you previous situaion." }
};

//***********ZONES**********************

string constants::ZONES_NAME[ZONE_TOTAL_NUMBER] = { "Narrow corridor" , "Narrow corridor", "Narrow corridor" , "Dark corridor", "Hall" , "Hall" ,"Upper Hall", "Upper Hall" };


int constants::ZONE_EXITS[constants::ZONE_TOTAL_NUMBER][constants::EXITS][2] =
{
	{{1,0},{0,1},{1,2},{2,WALL}},
	{{2,WALL},{0,2},{2,WALL},{0,0}},
	{{2,WALL},{2,WALL},{1,1},{0,1}},
	{{1,2},{1,3},{0,4},{2,WALL}},
	{{0,3},{0,5},{1,5},{1,8}},
	{{1,4},{0,6},{2,WALL},{0,4}},
	{{2,WALL},{0,7},{1,6},{0,5}},
	{{2,WALL},{1,7},{2,WALL},{0,6}}
};

string constants::ZONE_DESCRIPTION[ZONE_TOTAL_NUMBER] =
{
	{ "It's a small corridor, two people wouldn't fit here." },
	{ "There's a dry trail of blood leading to the east." },
	{ "It's a small corridor, two people wouldn't fit here." },
	{ "To the south you can see a dimm light" },
	{ "It's the lower hall, to the east there are some stairs that lead to the upper Hall, \nto the west there's a huge Gate leading outside. \nIt also seems there's some kind of passsage south. " },
	{ "Lower hall, the smell you noticed at the beginning grows stronger to the north." },
	{ "Upper hall, next to the clock there's a turned candlestick, it doesn't fit with all the others." },
	{ "Upper hall, there's a fairly big door to the east. It's pretty obvious where does it lead to" }
};

int constants::ITEMS_ZONE[ZONE_TOTAL_NUMBER][ITEM_TYPES_NUMBER] =
{
	{ NOITEM,NOITEM,NOITEM,NOITEM,NOITEM },
	{ NOITEM,NOITEM,NOITEM,NOITEM,NOITEM },
	{ NOITEM,NOITEM,NOITEM,NOITEM,NOITEM },
	{ NOITEM,NOITEM,NOITEM,NOITEM,NOITEM },
	{ NOITEM,NOITEM,NOITEM,NOITEM,NOITEM },
	{ NOITEM,NOITEM,APPLE,NOITEM,NOITEM },
	{ NOITEM,NOITEM,NOITEM,NOITEM,NOITEM },
	{ NOITEM,NOITEM,NOITEM,NOITEM,NOITEM }
};

//**********************ENEMIES********************************

string constants::ENEMIES_NAME[ENEMIES_TOTAL_NUMBER] = { "Goblin" , "Orc" , "Troll" , "Dragon" };

int constants::ENEMIES_HP[ENEMIES_TOTAL_NUMBER] = {10, 15, 20, 40};

int constants::ENEMIES_ATTACK[ENEMIES_TOTAL_NUMBER] = { 2, 3, 5, 7 };

int constants::ENEMIES_LOOT[ENEMIES_TOTAL_NUMBER][2]=
{
	{NOITEM ,NOITEM},
	{AXE, WEAPON},
	{KEY ,KEY_ITEM},
	{NOITEM , NOITEM}
};

constants::constants()
{
}


constants::~constants()
{
}
