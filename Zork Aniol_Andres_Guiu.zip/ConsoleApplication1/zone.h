#pragma once
#include "mapProgress.h"
#include "constants.h"

namespace Zerk 
{
	class zone
	{
	private:
		//Zone id
		int id;

		//Zone name
		string name;

		//Is there an item in this Zone?
		bool item;

		//Zone id item
		int idItem;

		//Zone item Type
		int itemType;

	public:
		zone();
		~zone();
		/**
		* sets Zone according to the id given
		*/
		void setZone(int id, mapProgress* progress);

		/**
		* saves zone status
		*/
		void saveZone(mapProgress* progress);
		


	};

}