#include "stdafx.h"
#include "zone.h"



using namespace Zerk;

using namespace std;

zone::zone()
{
}


zone::~zone()
{
}

/**
* Sets zone instance according to id given
*/
void zone::setZone(int id, mapProgress* progress)
{
	this->id = id;
	this->name = constants::ZONES_NAME[id];
	this->item = progress->getZoneStatus(id, 2);
	if (item)
	{
		for (int i = 0; i < constants::ITEM_TYPES_NUMBER; i++)
		{
			if (constants::ITEMS_ZONE[id][i] != 99)
			{
				this->idItem = constants::ITEMS_ZONE[id][i];
				this->itemType = i;
				break;
			}
		}
	}
}

/**
* saves Zone instance
*/
void zone::saveZone(mapProgress* progress)
{
	progress->setZoneStatus(id, ITEM, item);
}