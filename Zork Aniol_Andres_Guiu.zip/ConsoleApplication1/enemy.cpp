#include "stdafx.h"
#include "enemy.h"
#include "constants.h"
#include<string>

using namespace Zerk;

enemy::enemy()
{
	id = 0;
	name = "";
	hp = 0;
	death = true;
	attack = 0;
}

enemy::~enemy()
{
}

/**
* modifies enemy instance according to id given
* @id the id given
*/
void enemy::setEnemy(int id)
{
	this->id = id;
	this->attack = constants::ENEMIES_ATTACK[id];
	this->name = constants::ENEMIES_NAME[id];
	this->death = false;
	this->hp = constants::ENEMIES_HP[id];
	this->Loot[0] = constants::ENEMIES_LOOT[id][0];
	this->Loot[1] = constants::ENEMIES_LOOT[id][1];
}

bool enemy::checkDeath()
{
	if (hp<=0)
		return death=true;
	else 
		return false;
}