#include <iostream>
#include "stdafx.h"
#include "player.h"
#include "constants.h"
#include <string>
#include <cstdlib>
	
using namespace Zerk;

using namespace std;

player::player(room* room, zone* zone, mapProgress* progress, item* item, enemy* enemy)
{
	this->roomPlayer = room;
	this->enemyPlayer = enemy;
	this->progressPlayer = progress;
	this->zonePlayer = zone;
	this->itemPlayer = item;
	this->currentHp = maxHp = 30;
	this->attack = 1;
	this->defense = 0;
	this->weight = 0;
}



player::~player()
{
}

void player::setInitialPosition()
{
	for (int i = 0; i < 2; i++)
	{
		for (int j = 0; j < constants::ROOMS_TOTAL_NUMBER; j++)
		{
			position[i][j] = false;
		}
	}
	position[1][0] = true;
}

int player::getPositionType()
{
	for (int i = 0; i < 2; i++)
	{
		for (int j = 0; j < constants::ROOMS_TOTAL_NUMBER; j++)
		{
			if (position[i][j])
			{
				return i;
			}	
		}
	}
	return 0;
}

int player::getPositionId()
{
	for (int i = 0; i < 2; i++)
	{
		for (int j = 0; j < constants::ROOMS_TOTAL_NUMBER; j++)
		{
			if (position[i][j])
			{
				return j;
			}
			
		}
	}
	return 0;
}

bool player::checkEnemy(int id)
{
	return progressPlayer->getRoomStatus(id, 0);
}

void player::setNewPosition(int a, int b)
{
	for (int i = 0; i < 2; i++)
	{
		for (int j = 0; j < constants::ROOMS_TOTAL_NUMBER; j++)
		{
			position[i][j] = false;
		}
	}
	position[a][b] = true;
}

void player::movePlayer()
{
	if (getPositionType() == 0)
	{
		if (constants::ZONE_EXITS[getPositionId()][getDirection()][0] == 2)
		{
			cout << "You can't go that way." << endl;
		}
		else if (getPositionId() == 4 && getDirection() == WEST)
		{
			if (progressPlayer->getZoneStatus(4, 1))
			{
				cout << "There is a door in your way, it's locked and you can't force it open. \nYou will need a key." << endl;
				for (int i = 0; i < constants::MAX_WEIGHT; i++)
				{
					if (inventory[i][0] == KEY_ITEM && inventory[i][1] == KEY)
					{
						cout << "With a *click* the gate opens, you can finally go outside" << endl;
						progressPlayer->setZoneStatus(4, 1, false);
						setNewPosition(1, 8);
						fight(constants::ENEMIES_ROOM[getPositionId()]);
					}
				}
			}
		}
		else
		{
			setNewPosition(constants::ZONE_EXITS[getPositionId()][getDirection()][0], constants::ZONE_EXITS[getPositionId()][getDirection()][1]);
			getIntro(getPositionId(), getPositionType());
			if (checkEnemy(getPositionId()) && getPositionType() == 1)
				fight(constants::ENEMIES_ROOM[getPositionId()]);
			this->zonePlayer->saveZone(progressPlayer);
			if(getPositionType() == 1)
				this->roomPlayer->setRoom(getPositionId(), progressPlayer);
			else
				this->zonePlayer->setZone(getPositionId(), progressPlayer);
			
		}	
	}
	else
	{
		if (constants::ROOM_EXITS[getPositionId()][getDirection()][0] == 2)
		{
			cout << "You can't go that way." << endl;
		}
		else
		{
			setNewPosition(0, constants::ROOM_EXITS[getPositionId()][getDirection()][1]);
			getIntro(getPositionId(), getPositionType());
			this->roomPlayer->saveRoom(progressPlayer);
			this->zonePlayer->setZone(getPositionId(), progressPlayer);
		}
	}
}

void player::takeItem(string str)
{
	int type = 95;
	int j;
	if (getPositionType() == 0)
		{
			if (progressPlayer->getZoneStatus(getPositionId(), 2))
			{
				
				for (j = 0; j < constants::ITEM_TYPES_NUMBER; j++)
				{
					if (constants::ITEMS_ZONE[getPositionId()][j] != constants::NOITEM)
					{
						type = j;
						break;
					}
				}
				switch (type)
				{
				case 0:
					if (str == constants::WEAPONS_NAME[constants::ITEMS_ZONE[getPositionId()][type]])
						cout << "you took: " << constants::WEAPONS_NAME[constants::ITEMS_ZONE[getPositionId()][type]] << endl;
					else
						cout << "There is no " << str << " here." << endl;
					break;
				case 1:
					if (str == constants::ARMORS_NAME[constants::ITEMS_ZONE[getPositionId()][type]])
						cout << "you took: " << constants::ARMORS_NAME[constants::ITEMS_ZONE[getPositionId()][type]] << endl;
					else
						cout << "There is no " << str << " here." << endl;
					break;
				case 2:
					if (str == constants::CONSUMS_NAME[constants::ITEMS_ZONE[getPositionId()][type]])
					{
						cout << "you took: " << constants::CONSUMS_NAME[constants::ITEMS_ZONE[getPositionId()][type]] << endl;
						progressPlayer->setZoneStatus(getPositionId(), 2, false);
						saveItem(2, constants::ITEMS_ZONE[getPositionId()][type]);
					}
					else
						cout << "There is no " << str << " here." << endl;
					break;
				case 3:
					if (str == constants::KEY_ITEMS_NAME[constants::ITEMS_ZONE[getPositionId()][type]])
						cout << "you took: " << constants::KEY_ITEMS_NAME[constants::ITEMS_ZONE[getPositionId()][type]] << endl;
					else
						cout << "There is no " << str << " here." << endl;
					break;
				case 4:
					if (str == constants::GEMS_NAME[constants::ITEMS_ZONE[getPositionId()][type]])
						cout << "you took: " << constants::GEMS_NAME[constants::ITEMS_ZONE[getPositionId()][type]] << endl;
					else
						cout << "There is no " << str << " here." << endl;
					break;
				}			
			}
			else
				cout << "There is no " << str << " here." << endl;
		}
	else
	{
		if (progressPlayer->getRoomStatus(getPositionId(), 1) && str !="Note")
		{
			for (j = 0; j < constants::ITEM_TYPES_NUMBER + 1; j++)
			{
				if (constants::ITEMS_ROOM[getPositionId()][j][0] != constants::NOITEM)
				{
					type = j;
					break;
				}
			}
			switch (type)
			{
			case WEAPON:
				if (str == constants::WEAPONS_NAME[constants::ITEMS_ROOM[getPositionId()][type][0]])
				{
					cout << "you took: " << constants::WEAPONS_NAME[constants::ITEMS_ROOM[getPositionId()][type][0]] << endl;
					saveItem(0, constants::ITEMS_ROOM[getPositionId()][type][0]);
				}
				else
					cout << "There is no " << str << " here." << endl;
				break;
			case ARMOR:
				if (str == constants::ARMORS_NAME[constants::ITEMS_ROOM[getPositionId()][type][0]])
				{
					saveItem(1, constants::ITEMS_ROOM[getPositionId()][type][0]);
					cout << "you took: " << constants::ARMORS_NAME[constants::ITEMS_ROOM[getPositionId()][type][0]] << endl;
				}
				else
					cout << "There is no " << str << " here." << endl;
				break;
			case CONSUM:
				if (str == constants::CONSUMS_NAME[constants::ITEMS_ROOM[getPositionId()][type][0]])
				{
					saveItem(2, constants::ITEMS_ROOM[getPositionId()][type][0]);
					cout << "you took: " << constants::CONSUMS_NAME[constants::ITEMS_ROOM[getPositionId()][type][0]] << endl;
				}
				else
					cout << "There is no " << str << " here." << endl;
				break;
			case KEY_ITEM:
				if (str == constants::KEY_ITEMS_NAME[constants::ITEMS_ROOM[getPositionId()][type][0]])
				{
					cout << "you took: " << constants::KEY_ITEMS_NAME[constants::ITEMS_ROOM[getPositionId()][type][0]] << endl;
					saveItem(3, constants::ITEMS_ROOM[getPositionId()][type][0]);
				}
				else
					cout << "There is no " << str << " here." << endl;
				break;
			case GEM:
				if (str == constants::GEMS_NAME[constants::ITEMS_ROOM[getPositionId()][type][0]])
				{
					saveItem(4, constants::ITEMS_ROOM[getPositionId()][type][0]);
					cout << "you took: " << constants::GEMS_NAME[constants::ITEMS_ROOM[getPositionId()][type][0]] << endl;
				}
				else
					cout << "There is no " << str << " here." << endl;
				break;
			}
			progressPlayer->setRoomStatus(getPositionId(), 1, false);
		}
		else if(progressPlayer->getRoomStatus(getPositionId(), 2) && str == "Note")
		{
			for (j = 0; j < constants::ITEM_TYPES_NUMBER + 1; j++)
			{
				if (constants::ITEMS_ROOM[getPositionId()][j][1] != constants::NOITEM)
				{
					type = j;
				}
			}
			switch (type)
			{
			case 0:
				if (str == constants::WEAPONS_NAME[constants::ITEMS_ROOM[getPositionId()][type][1]])
				{
					saveItem(0, constants::ITEMS_ROOM[getPositionId()][type][1]);
					cout << "you took: " << constants::WEAPONS_NAME[constants::ITEMS_ROOM[getPositionId()][type][1]] << endl;
				}
				else
					cout << "There is no " << str << " here." << endl;

				break;
			case 1:
				if (str == constants::ARMORS_NAME[constants::ITEMS_ROOM[getPositionId()][type][1]])
				{
					saveItem(1, constants::ITEMS_ROOM[getPositionId()][type][1]);
					cout << "you took: " << constants::ARMORS_NAME[constants::ITEMS_ROOM[getPositionId()][type][1]] << endl;
				}
				else
					cout << "There is no " << str << " here." << endl;
				break;
			case 2:
				if (str == constants::CONSUMS_NAME[constants::ITEMS_ROOM[getPositionId()][type][1]])
				{
					saveItem(2, constants::ITEMS_ROOM[getPositionId()][type][1]);
					cout << "you took: " << constants::CONSUMS_NAME[constants::ITEMS_ROOM[getPositionId()][type][1]] << endl;
				}
				else
					cout << "There is no " << str << " here." << endl;
				break;
			case 3:
				if (str == constants::KEY_ITEMS_NAME[constants::ITEMS_ROOM[getPositionId()][type][1]])
				{
					saveItem(3, constants::ITEMS_ROOM[getPositionId()][type][1]);
					cout << "you took: " << constants::KEY_ITEMS_NAME[constants::ITEMS_ROOM[getPositionId()][type][1]] << endl;
				}
				else
					cout << "There is no " << str << " here." << endl;
				break;
			case 4:
				if (str == constants::GEMS_NAME[constants::ITEMS_ROOM[getPositionId()][type][1]])
				{
					saveItem( 4, constants::ITEMS_ROOM[getPositionId()][type][1]);
					cout << "you took: " << constants::GEMS_NAME[constants::ITEMS_ROOM[getPositionId()][type][1]] << endl;
				}
				else
					cout << "There is no " << str << " here." << endl;
			}
			progressPlayer->setRoomStatus(getPositionId(), 2, false);
		}
		else
			cout << "There is no " << str << " here." << endl;
	}
}

void player::saveItem(int type, int id)
{
	for (int i = 0; i < constants::MAX_WEIGHT; i++)
	{
		if (inventory[i][0]==constants::NOITEM)
		{
			inventory[i][0] = type;
			inventory[i][1] = id;
			weight++;
			break;
		}
	}
	if (weight == constants::MAX_WEIGHT)
		cout << "There is no more room in your inventory." << endl;
}


void player::getInventoryDescription()
{
	for (int i = 0; i < constants::MAX_WEIGHT; i++)
	{
		if (inventory[i][0] != constants::NOITEM)
		{
			switch (inventory[i][0])
			{
				case 0:
					cout << constants::WEAPONS_NAME[inventory[i][1]] << endl;
				break;
				case 1:
					cout << constants::ARMORS_NAME[inventory[i][1]] << endl;
				break;
				case 2:
					cout << constants::CONSUMS_NAME[inventory[i][1]] << endl;
				break;
				case 3:
					cout << constants::KEY_ITEMS_NAME[inventory[i][1]] << endl;
				break;
				case 4:
					cout << constants::GEMS_NAME[inventory[i][1]] << endl;
				break;
			}
		}
	}
}

void player::dropItem(string str)
{
	bool equip = false;
	for (int i = 0; i < constants::MAX_WEIGHT; i++)
	{
		if (inventory[i][1] != constants::NOITEM)
		{
			for (int a = 0; a < 3; a++)
			{
				if (inventory[i][0] == itemEquiped[a][0] && inventory[i][1] == itemEquiped[a][1])
				{
					cout << "You can't drop an equiped item" << endl;
					equip = true;
					break;
				}
			}
			if (equip == false)
			{
				switch (inventory[i][0])
				{
				case WEAPON:

					if (constants::WEAPONS_NAME[inventory[i][1]] == str)
					{
						cout << "You dropped " << constants::WEAPONS_NAME[inventory[i][1]] << endl;;
						inventory[i][0] = constants::NOITEM;
						inventory[i][1] = constants::NOITEM;
						weight--;
					}
					break;
				case ARMOR:
					if (constants::ARMORS_NAME[inventory[i][1]] == str)
					{
						cout << "You dropped " << constants::ARMORS_NAME[inventory[i][1]] << endl;;
						inventory[i][0] = constants::NOITEM;
						inventory[i][1] = constants::NOITEM;
						weight--;
					}
					break;
				case CONSUM:
					if (constants::CONSUMS_NAME[inventory[i][1]] == str)
					{
						cout << "You dropped " << constants::CONSUMS_NAME[inventory[i][1]] << endl;;
						inventory[i][0] = constants::NOITEM;
						inventory[i][1] = constants::NOITEM;
						weight--;
					}
					break;
				case KEY_ITEM:
					if (constants::KEY_ITEMS_NAME[inventory[i][1]] == str)
					{
						cout << "You can't drop a Key item." << endl;
					}
					break;
				case GEM:
					if (constants::GEMS_NAME[inventory[i][1]] == str)
					{
						cout << "You dropped " << constants::GEMS_NAME[inventory[i][1]] << endl;;
						inventory[i][0] = constants::NOITEM;
						inventory[i][1] = constants::NOITEM;
						weight--;
					}
					break;
				}

			}

		}
	}
}

void player::getDescription(int id, int type)
{
	if (type == 1)
	{
		cout << constants::ROOM_DESCRIPTION[id][1] << endl << endl;
		itemFloor();
	}
	else
	{
		cout << constants::ZONE_DESCRIPTION[id] << endl;
		itemFloor();
	}
	
}

void player::getIntro(int id, int type)
{
	if (type == 0)
	{
		cout << constants::ZONES_NAME[id] << endl;
	}
	else
		cout << constants::ROOM_DESCRIPTION[id][0] << endl;
}

void player::useItem(string str)
{
	itemPlayer->setId(constants::NOITEM);
	for (int i = 0; i < constants::MAX_WEIGHT; i++)
	{
		switch (inventory[i][0])
		{
		case WEAPON:
			if(str == constants::WEAPONS_NAME[inventory[i][1]])
				itemPlayer->setItem(inventory[i][1], inventory[i][0]);
			break;
		case ARMOR:
			if (str == constants::ARMORS_NAME[inventory[i][1]])
				itemPlayer->setItem(inventory[i][1], inventory[i][0]);
			break;
		case CONSUM:
			if (str == constants::CONSUMS_NAME[inventory[i][1]])
				itemPlayer->setItem(inventory[i][1], inventory[i][0]);
			break;
		case KEY_ITEM:
			if (str == constants::KEY_ITEMS_NAME[inventory[i][1]])
				itemPlayer->setItem(inventory[i][1], inventory[i][0]);
			break;
		case GEM:
			if (str == constants::GEMS_NAME[inventory[i][1]])
				itemPlayer->setItem(inventory[i][1], inventory[i][0]);
			break;
		}
	}
	if (itemPlayer->getId() != constants::NOITEM)
	{
		switch (itemPlayer->getItemType())
		{
		case WEAPON:
			if(itemPlayer->getId()==bonusAttack[0])
				attack = itemPlayer->getAttack() + bonusAttack[1]+1;
			else
				attack = itemPlayer->getAttack() + 1;
			equip(itemPlayer->getId(), itemPlayer->getItemType());
			break;
		case ARMOR:
			equip(itemPlayer->getId(), itemPlayer->getItemType());
			break;
		case CONSUM:
			currentHp = currentHp + itemPlayer->getEffect();
			if (currentHp > maxHp)
			{
				currentHp = maxHp;
			}
			eraseItem(str);
			break;
		case KEY_ITEM:
			cout << constants::KEY_ITEMS_USE[itemPlayer->getId()] << endl << endl;
			break;
		case GEM:
			enhance();
			break;

		}
	}
	else
		cout << "You don't have the item: " << str << endl;
}

void player::eraseItem(string str)
{
	for (int i = 0; i < constants::MAX_WEIGHT; i++)
	{
		if (inventory[i][0] == CONSUM && str == constants::CONSUMS_NAME[inventory[i][1]])
		{
			cout << "You have used: " << str << endl;
			inventory[i][1] = constants::NOITEM;
			inventory[i][0] = constants::NOITEM;
			break;
		}
	}
}

void player::equip(int id, int type)
{
	switch (type)
	{
	case WEAPON:
		unequip(WEAPON);
		cout << "You have equiped: " << constants::WEAPONS_NAME[id] << endl;
		itemEquiped[0][0] = id;
		itemEquiped[0][1] = type;
		break;
	case ARMOR:
		if (id == BUCKLER)
		{
			itemEquiped[1][0] = id;
			itemEquiped[1][1] = type;
		}
		else if (id == CHAINMAIL)
		{
			itemEquiped[2][0] = id;
			itemEquiped[2][1] = type;
		}
		this->defense = 0;
		if (itemEquiped[1][0] != constants::NOITEM)
			this->defense += constants::ARMORS_DEF[itemEquiped[1][0]];
		if (itemEquiped[2][0] != constants::NOITEM)
			this->defense += constants::ARMORS_DEF[itemEquiped[2][0]];
		cout << "You have equiped: " << constants::ARMORS_NAME[id] << endl;
		break;
	}
}

void player::unequip(int type) 
{
	itemEquiped[type][0] = constants::NOITEM;
	itemEquiped[type][1] = constants::NOITEM;
}

void player::getEquipDescription()
{
	for (int i = 0; i < 3; i++)
	{
		if (itemEquiped[i][0] != constants::NOITEM)
		{
			switch (itemEquiped[i][1])
			{
			case WEAPON:
				cout << constants::WEAPONS_NAME[itemEquiped[i][0]] << endl;
				break;
			case ARMOR:
				cout << constants::ARMORS_NAME[itemEquiped[i][0]] << endl;
				break;
			}
		}
	}
}

void player::itemFloor()
{
	if(getPositionType() == 0)
	{
		if (progressPlayer->getZoneStatus(getPositionId(), 2))
		{
			cout << "You can see on the floor: " << constants::CONSUMS_NAME[constants::ITEMS_ZONE[getPositionId()][2]] << endl;
		}
	}
	else
	{
		if (progressPlayer->getRoomStatus(getPositionId(), 1) || progressPlayer->getRoomStatus(getPositionId(), 2))
		{
			cout << "You can see on the floor: " << endl;
		}
		if (progressPlayer->getRoomStatus(getPositionId(), 1))
		{
			for (int i = 0; i < constants::ITEM_TYPES_NUMBER; i++)
			{
				if (constants::ITEMS_ROOM[getPositionId()][i][0] != constants::NOITEM)
				{
					switch (i)
					{
					case WEAPON:
						cout << constants::WEAPONS_NAME[constants::ITEMS_ROOM[getPositionId()][i][0]] << endl;
						break;
					case ARMOR:
						cout << constants::ARMORS_NAME[constants::ITEMS_ROOM[getPositionId()][i][0]] << endl;
						break;
					case CONSUM:
						cout << constants::CONSUMS_NAME[constants::ITEMS_ROOM[getPositionId()][i][0]] << endl;
						break;
					case KEY_ITEM:
						cout << constants::KEY_ITEMS_NAME[constants::ITEMS_ROOM[getPositionId()][i][0]] << endl;
						break;
					case GEM:
						cout << constants::GEMS_NAME[constants::ITEMS_ROOM[getPositionId()][i][0]] << endl;
						break;

					}
				}
			}
		}
		if(progressPlayer->getRoomStatus(getPositionId(), 2))
		{
				if (constants::ITEMS_ROOM[getPositionId()][KEY_ITEM][1] != constants::NOITEM)
				{
					cout << constants::KEY_ITEMS_NAME[constants::ITEMS_ROOM[getPositionId()][KEY_ITEM][1]] << endl;
				}
		}
		
	}
}

void player::enhance()
{
	if (bonusAttack[1] == constants::NOITEM)
	{
		cout << "You have enhanced your " << constants::WEAPONS_NAME[itemEquiped[0][0]] << "!" << endl;
		setBonusAttack(1, constants::GEM_POWER[0]);
		setBonusAttack(0,itemEquiped[0][0]);
		this->attack = 1 + constants::WEAPONS_DMG[itemEquiped[0][0]] + getBonusAttack(1);
		for (int i = 0; i < constants::MAX_WEIGHT; i++)
		{
			if (inventory[i][0] == GEM)
			{
				inventory[i][0] = constants::NOITEM;
				inventory[i][1] = constants::NOITEM;
				break;
			}
		}
	}
}

void player::fight(int id)
{
	switch (id)
	{
	case GOBLIN:
		cout << endl <<"You surprise a lowly goblin who was busy browsing throw the items in a cupboard, \nHe looks clearly angry you've disturbed him, it seems you'll have to fight your way through." << endl << endl;
		break;
	case ORC:
		cout << endl << "A powerful Orc is waiting for you in this room, he positions himself between you and the door, \nfighting is the only option." << endl << endl;
		break;
	case TROLL:
		cout << endl << "A mighty Troll is sleeping in the Throne Room, as he wakes up he tries to investigate what woke him up,\nHe looks at you full of anger, you'll need to defeat this foe if you want to continue!" << endl << endl;
		break;
	case DRAGON:
		cout << endl << "A person stands in the middle of the courtyard, he smiles and looks at you.\n\n*Look at you, who would have thought you would make it all the way here.\nI'm sorry to disappoint you but you'll go no further* \nWith an evil laugh he transforms to a Dragon, before you stands your last trial. Fight for your life" << endl << endl;
		break;
	}
	enemyPlayer->setEnemy(id);
	string input;
	bool death = false;
	enemyPlayer->setEnemy(constants::ENEMIES_ROOM[getPositionId()]);
	while (death == false)
	{
		while (true)
		{
			getline(cin, input);
			if (input == "Attack" || input == "attack")
			{
				int playerDmg;
				playerDmg = getAttack();
				enemyPlayer->takeDamage(playerDmg);
				cout << "You strike the enemy for a total of " << playerDmg << " points of damage!" << endl << endl;
				break;
			}
			else if (input == "Help" || input == "help")
			{
				cout << endl << "*******************HELP************************" << endl;
				cout << "Type *Attack* to damage your foe! Do your best!!" << endl;
				cout << "***********************************************" << endl;
			}
			else
				cout << "I didn't understand your command." << endl;
		}

		if (enemyPlayer->checkDeath())
		{
			if (id == DRAGON)
			{
				cout << "The dragon bends to the right as you pull back your weapon. \nYou are both very tired but taking advantatge of the recovery you strike swiftly the neck of the Beast. \nBlood comes gauging out as the Game Master reverts to his human form. \nHow did ... how could you?\nWith a last exhale the Game Master drops to the floor. \nYou are finally free! Well done Warrior!" << endl;
				cout << "Thank you for playing this short demo, hope you enjoyed it." << endl << endl;
				cout << "Aniol." << endl << endl;
				cout << "FIN" << endl;
				getchar();
				exit(0);
			}
			cout << "Victory!" << endl;
			progressPlayer->setRoomStatus(getPositionId(), 0, false);
			death = true;
			if (constants::ENEMIES_LOOT[id][0] != constants::NOITEM)
			{
				saveItem(constants::ENEMIES_LOOT[id][1], constants::ENEMIES_LOOT[id][0]);
					switch (constants::ENEMIES_LOOT[id][1])
					{
					case WEAPON:
						cout << "You have received: " <<  constants::WEAPONS_NAME[constants::ENEMIES_LOOT[id][0]]  << endl;
						break;
					case KEY_ITEM:
						cout << "You have received: " << constants::KEY_ITEMS_NAME[constants::ENEMIES_LOOT[id][0]] << endl;
						break;
					}
			}
		}
		else
		{
			int enemyDmg;
			enemyDmg = enemyPlayer->getAttack() - defense;
			currentHp = currentHp - ((enemyPlayer->getAttack()) - defense);
			cout << "the enemy hits you for " << enemyDmg << " damage."<<  endl << endl;
			if (currentHp <= 0)
			{
				cout << "You are struck by a fatal blow to the side of your head, \nyour vision grows blurry as the ground gets up to receive you." << endl << endl;

				cout << "You died." << endl << endl;

				cout << "GAME OVER" << endl;
				getchar();
				exit(0);
			}
		}
	}
}