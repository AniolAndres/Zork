#pragma once
#include<iostream>

using namespace std;

namespace Zerk
{

enum enemies
{
	GOBLIN = 0,
	ORC = 1,
	TROLL = 2,
	DRAGON =3
};

enum items_type

{
	WEAPON = 0,
	ARMOR = 1,
	CONSUM = 2,
	KEY_ITEM = 3,
	GEM = 4
};

enum weapons
{
	KNIFE = 0,
	AXE = 1,
	SWORD = 2
};

enum armors
{
	BUCKLER = 0,
	CHAINMAIL = 1
};

enum key_items
{
	NOTE = 0,
	KEY = 1
};

enum consums

{
	CHEESE = 0,
	HEALTH_POTION = 1,
	APPLE = 2
};

enum gems
{
	REDGEM = 0
};

enum rooms
{
	CELL = 0,
	TORTURE_CHAMBER = 1,
	GUARDS_ROOM = 2,
	BARRACKS = 3,
	KITCHEN = 4,
	SERVANTS_ROOM = 5,
	TREASURE_ROOM = 6,
	THRONE_ROOM = 7,
	COURTYARD = 8
};

enum zones
{
	CORRIDOR_1 = 0,
	CORRIDOR_2 = 1,
	HALL = 3
};

enum room_variables

{
	ENEMY = 0,
	ITEM1 = 1,
	ITEM2 = 2,
	DOOR = 3,
	NPC = 4
};

enum zone_variables

{
	LOOK=0,
	ZONEDOOR=1,
	ITEM=2
};

enum exits

{
	NORTH=0,
	EAST=1,
	SOUTH=2,
	WEST=3
};


class constants
{
public:
	//***************MISC**************

	static const int EXITS = 4;

	static const int NOITEM = 99;

	static const int NOFOE = 95;

	static const int MAX_WEIGHT = 20;

	//*************ITEMS*****************

	static const int ITEM_TYPES_NUMBER = 5;

	//***********WEAPONS**********************

	static const int WEAPONS_TOTAL_NUMBER = 3;

	static string WEAPONS_NAME[WEAPONS_TOTAL_NUMBER];

	static int WEAPONS_DMG[WEAPONS_TOTAL_NUMBER];

	//***********ARMORS**********************

	static const int ARMORS_TOTAL_NUMBER = 2;

	static string ARMORS_NAME[ARMORS_TOTAL_NUMBER];

	static int ARMORS_DEF[ARMORS_TOTAL_NUMBER];

	//***********CONSUMS**********************

	static const int CONSUMS_TOTAL_NUMBER = 3;

	static string CONSUMS_NAME[CONSUMS_TOTAL_NUMBER];

	static int CONSUMS_HEALING_VALUE[CONSUMS_TOTAL_NUMBER];

	//***********KEY ITEMS**********************

	static const int KEY_ITEMS_TOTAL_NUMBER = 2;

	static string KEY_ITEMS_NAME[KEY_ITEMS_TOTAL_NUMBER];

	static string KEY_ITEMS_USE[KEY_ITEMS_TOTAL_NUMBER];

	//***********GEMS**********************

	static const int GEMS_TOTAL_NUMBER = 1;

	static string GEMS_NAME[GEMS_TOTAL_NUMBER];

	static int GEM_POWER[GEMS_TOTAL_NUMBER];

	//***********ROOMS**********************


	static const int ROOMS_TOTAL_NUMBER = 9;

	static string ROOMS_NAME[ROOMS_TOTAL_NUMBER];

	static const int ROOM_VALUES_TOTAL_NUMBER = 5;

	static int ROOM_EXITS[ROOMS_TOTAL_NUMBER][EXITS][2];

	static int ITEMS_ROOM[ROOMS_TOTAL_NUMBER][ITEM_TYPES_NUMBER][2];

	static int ENEMIES_ROOM[ROOMS_TOTAL_NUMBER];

	static const int ROOM_VARIABLES_TOTAL_NUMBER = 3;

	static string ROOM_DESCRIPTION[ROOMS_TOTAL_NUMBER][2];

	static string ROOM_VARIABLES_NAME[ROOM_VARIABLES_TOTAL_NUMBER];
	
	//***********ZONES*****************

	static const int ZONE_TOTAL_NUMBER = 8;

	static const int ZONES_VALUE_TOTAL_NUMBER = 3;

	static string ZONES_NAME[ZONE_TOTAL_NUMBER];

	static int ZONE_EXITS[ZONE_TOTAL_NUMBER][EXITS][2];

	static int ITEMS_ZONE[ZONE_TOTAL_NUMBER][ITEM_TYPES_NUMBER];

	static string ZONE_DESCRIPTION[ZONE_TOTAL_NUMBER];

	//**************ENEMIES*****************

	static const int ENEMIES_TOTAL_NUMBER = 4;

	static string ENEMIES_NAME[ENEMIES_TOTAL_NUMBER];

	static int ENEMIES_HP[ENEMIES_TOTAL_NUMBER];

	static int ENEMIES_ATTACK[ENEMIES_TOTAL_NUMBER];

	static int ENEMIES_LOOT[ENEMIES_TOTAL_NUMBER][2];

	constants();

	~constants();
};

}