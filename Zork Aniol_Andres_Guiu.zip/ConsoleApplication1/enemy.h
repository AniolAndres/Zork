#pragma once
#include<string>

using namespace std;

namespace Zerk
{


	class enemy
	{
	private:
		//Enemy id
		int id;

		//Enemy name
		string name;

		//Enemy hp
		int hp;

		//Enemy attack
		int attack;

		//Enemy loot
		int Loot[2];

		//enemy Death
		bool death;

	public:
		enemy();
		~enemy();

		/**
		* modifies enemy instance according to id given
		*/
		void setEnemy(int id);

		/**
		* Returns attack value of the enemy
		*/
		int getAttack() { return attack; };

		/**
		* reduces enemy hp according to damage done
		*/
		void takeDamage(int damage) { hp = hp - damage; };
			
		/**
		* checks death of the enemy
		*/
		bool checkDeath();

	};

}