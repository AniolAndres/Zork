#pragma once
#include <string>
#include<iostream>
#include "room.h"
#include "player.h"


using namespace std;

namespace Zerk
{

	class world
	{
	private:
		
	public:

		/**
		* switches between possible choices according to string given
		*/
		void choice(string x,player* player);

		world();
		~world();
	};

}