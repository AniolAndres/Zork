#pragma once
#include "constants.h"

namespace Zerk
{

	class mapProgress
	{
	private:

		bool roomStatus[constants::ROOMS_TOTAL_NUMBER][constants::ROOM_VALUES_TOTAL_NUMBER] = 
		{
			//enemy,item1,item2,door,npc
			{ false, true, true, false,false },
			{ false, true, false, false, false },
			{ true,false,false,false,false },
			{ false,true,false,false,false },
			{ false,true,false,false,false },
			{ true,true,false,false,true },
			{ false,true,false,false,false },
			{ true,true,false ,false ,false },
			{ true, false ,false ,false ,false }
		};	

		bool zoneStatus[constants::ZONE_TOTAL_NUMBER][constants::ZONES_VALUE_TOTAL_NUMBER] =
		{
			//look,door,item
			{ false,false,false },
			{ true,false,false },
			{ false,false,false },
			{ false,false,false },
			{ false,true,false },
			{ false,false,true },
			{ false,false,false },
			{ false,false,false }
		};

	public:
		mapProgress();
		~mapProgress();

		/**
		* returns Zone status according to zone id and item value
		*/
		bool getZoneStatus(int a, int b) { return zoneStatus[a][b]; };

		/**
		* sets Zone status according to zone id, item value and bool
		*/
		void setZoneStatus(int a, int b, bool c) { zoneStatus[a][b] = c; };

		/**
		* returns Room status according to zone id and item value
		*/
		bool getRoomStatus(int a, int b) { return roomStatus[a][b]; };

		/**
		* sets Room status according to zone id, item value and bool
		*/
		void setRoomStatus(int a, int b, bool c) { roomStatus[a][b] = c; };
	};
}