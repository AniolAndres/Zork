#include "stdafx.h"
#include "world.h"
#include<ctype.h>
#include<iostream>
#include<string>
#include "player.h"

using namespace std;

using namespace Zerk;

void world::choice(string x,player* player)
{
	string aux = x;
	string aux2 = aux.substr(0, aux.find(" "));

	if (x == "look" || x == "Look" || x == "l")
	{
		player->getDescription(player->getPositionId(), player->getPositionType());
	}
	else if (x == "fight" || x == "Fight" || x == "f")
	{
		cout << "You are fighting" << endl;
	}
	else if (x == "west" || x == "West" || x == "w")
	{
		player->setDirection(WEST);
		player->movePlayer();
	
	}
	else if (x == "north" || x == "North" || x == "n")
	{
		player->setDirection(NORTH);
		player->movePlayer();
	}
	else if (x == "south" || x == "South" || x == "s")
	{
		player->setDirection(SOUTH);
		player->movePlayer();
	}
	else if (x == "east" || x == "East" || x == "e")
	{
		player->setDirection(EAST);
		player->movePlayer();
	}
	else if (x == "Inventory" || x == "inventory")
	{
		cout << "You are currently holding:" << endl << endl;
		cout << "***INVENTORY***" << endl;
		player->getInventoryDescription();
		cout << "***************" << endl << endl;
	}
	else if (x == "Equip" || x == "equip")
	{
		cout << "You have currently equiped:" << endl << endl;
		cout << "*****EQUIP*****" << endl;
		player->getEquipDescription();
		cout << "***************" << endl << endl;
	}
	else if (aux2=="take" || aux2== "Take" || aux2 == "t")
	{
		int aux3 = x.find_last_of(" \t\n");
		aux = x.substr(aux3 + 1);
		player->takeItem(aux);
	}
	else if (aux2 == "Use" || aux2 == "use")
	{

		int aux3 = x.find_last_of(" \t\n");
		aux = x.substr(aux3 + 1);
		player->useItem(aux);
	}
	else if (aux2 == "Drop" || aux2 == "drop" || aux2 == "d")
	{
		int aux3 = x.find_last_of(" \t\n");
		aux = x.substr(aux3 + 1);
		player->dropItem(aux);
	}
	else if(x=="Status" || x=="status")
	{
		cout << "Attack: " << player->getAttack() << endl;
		cout << "Defense: " << player->getDefense() << endl;
		cout << "HP: " << player->getCurrentHp() << "/" << player->getMaxHp() << endl;

	}
	else if (x == "GOD")
	{
		player->god();
	}
	else if (x == "Help" || x == "help")
	{
		cout << endl << "******************************COMMANDS**********************************" << endl;
		cout << "North, West, East, South: To move between Rooms, you can't move while fighting!" << endl;
		cout << "Status: Check your parameters." << endl;
		cout << "Look: Check the room for items and a larger description." << endl;
		cout << "Take (item name): To pick up items from the floor." << endl;
		cout << "Use (item name): To equip weapons and armor and use consumibles." << endl;
		cout << "Drop (item name): To drop items, you can't take them back once thrown!" << endl;
		cout << "Inventory: To check the items you are carrying." << endl;
		cout << "Equip: To check the items you have equiped, you won't gain any stats for just having them in the inventory!." << endl;
		cout << "Command Help also works in combat!" << endl;
		cout << "************************************************************************" << endl;
	}
	else
	{
		cout << "I didn't understand your command" << endl;
	}

	
	
}




world::world()
{
}


world::~world()
{
}
